
import React, { useState, useEffect } from 'react';
import { X, Crown, CreditCard, Loader2, AlertCircle, Mail, Key } from 'lucide-react';
import { Elements, CardElement, useStripe, useElements } from "@stripe/react-stripe-js";

// src/checkout.js
import { loadStripe } from "@stripe/stripe-js";
import { InputField } from './AdminAuth';
import { Timestamp } from 'firebase/firestore';
import { signup } from '@/services/firebaseService';

// Static Stripe Payment Links as requested by the user.
// const ONETIME_PAYMENT_LINK = 'https://buy.stripe.com/eVq3cveBvbISgDF9Mqdwc0m';
// const SUBSCRIPTION_PAYMENT_LINK = 'https://buy.stripe.com/00w7sLgJD3cm0EH5wadwc0n';

interface UsageLimitModalProps {
  onClose: () => void;
  isUpgradeFlow?: boolean;
}


// load your public key from env (VITE_ prefix required for vite)
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUB_KEY);
const api_url = import.meta.env.VITE_STRIPE_API_URL;

const CheckoutForm = ({ closeModal }) => {
  const stripe = useStripe();
  const elements = useElements();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState(""); // you’d normally handle this in your backend
  const [confirmPass, setConfirmPass] = useState("");
  const [plan, setPlan] = useState("basic");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // const handleSubmit = async (e: React.FormEvent) => {
  //   e.preventDefault();

  //   if (password !== confirmPass) {
  //     setError("Your confirmation password doesn’t match the one above!");
  //     return;
  //   }

  //   // if not stripe load then return error
  //   if (!stripe || !elements) {
  //     console.log('stripe not loaded');
  //     setError('stripe not loaded');
  //     return
  //   }

  //   // Confirm card payment with Stripe
  //   const cardElement = elements.getElement('card');
  //   // if card elements not loaded return error
  //   if (!cardElement) {
  //     setLoading(false);
  //     setError("card elements loading error");
  //     return;
  //   }
  //   const data: any = {
  //     email, amount: plan === "basic" ? 100 : 499, currency: "eur"
  //   }

  //   if (cardElement) {
  //     setLoading(true);
  //     setError(null);
  //     // generate a stripe payment token
  //     stripe
  //       .createToken(cardElement, data)
  //       .then(async (payload) => {
  //         console.log("payload", payload);
  //         const stripeUserAccToken = payload?.token?.id;
  //         if (stripeUserAccToken) {
  //           // Prepare data to send to backend
  //           const paymentData = {
  //             email,
  //             token: stripeUserAccToken,
  //             amount: plan === "basic" ? 100 : 499, // amount in cents
  //             currency: "eur",
  //           };
  //           // Call your backend to create PaymentIntent
  //           const res = await fetch(`${api_url}/subscribe`, {
  //             method: "POST",
  //             headers: { "Content-Type": "application/json" },
  //             body: JSON.stringify(paymentData),
  //           });

  //           console.log("res", res);
  //           if (!res.ok) {
  //             setError(res?.error?.message || "Payment failed, please try again");
  //             setLoading(false);
  //             return;
  //           }

  //           const result = await res.json();
  //           console.log("result", result);



  //           // Create expiry date 30 days from now
  //           const expiryDate = new Date();
  //           expiryDate.setDate(expiryDate.getDate() + 30);

  //           // Convert to Firestore Timestamp
  //           const expiryTimestamp = Timestamp.fromDate(expiryDate);


  //           const new_user_data = {
  //             email: email.toLowerCase(),
  //             password: password,
  //             expire_on: expiryTimestamp,
  //             is_limited_access: plan === 'basic',
  //             usage_limit: (plan === 'basic' ? 3 : -1),
  //           };

  //           await signup(new_user_data);
  //           setLoading(false);

  //           // console.log("result", result);
  //           alert("✅ Payment successful!");
  //           closeModal();

  //         } else {
  //           console.log("error", error);
  //           // set loading false
  //           setLoading(false);
  //           // set error
  //           setError(payload?.error?.message || 'An error occurred');
  //         }
  //       })
  //       .catch((error) => {
  //         console.log("error", error);
  //         // set loading false
  //         setLoading(false);
  //         // set error
  //         setError(error?.message || error?.response?.data?.message || 'An error occurred');
  //       }).finally(() => {
  //         setLoading(false);
  //       });
  //   }
  // };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (password !== confirmPass) {
      setError("Your confirmation password doesn’t match the one above!");
      return;
    }

    if (!stripe || !elements) {
      setError("Stripe not loaded");
      return;
    }

    const cardElement = elements.getElement("card");
    if (!cardElement) {
      setError("Card elements loading error");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Step 1: Create Stripe token
      const payload = await stripe.createToken(cardElement, {
        email,
        amount: plan === "basic" ? 100 : 499,
        currency: "gbp",
      });

      if (payload.error) {
        throw new Error(payload.error.message);
      }

      const stripeUserAccToken = payload?.token?.id;
      if (!stripeUserAccToken) {
        throw new Error("Failed to create Stripe token");
      }

      // Step 2: Send to backend
      const paymentData = {
        email,
        token: stripeUserAccToken,
        amount: plan === "basic" ? 100 : 499,
        currency: "gbp",
      };

      const res = await fetch(`${api_url}/subscribe`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(paymentData),
      });

      const result = await res.json();

      if (!res.ok || !result.success) {
        throw new Error(result.error || "Payment failed, please try again");
      }

      // Step 3: Handle subscription expiry date
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + 30);
      const expiryTimestamp = Timestamp.fromDate(expiryDate);

      const new_user_data = {
        email: email.toLowerCase(),
        password,
        expire_on: expiryTimestamp,
        is_limited_access: plan === "basic",
        usage_limit: plan === "basic" ? 3 : -1,
      };

      await signup(new_user_data);

      alert("✅ Payment successful!");
      closeModal();
    } catch (err: any) {
      console.error("Payment error", err);
      setError(err.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };


  const cardElementOptions = {
    style: {
      base: {
        fontSize: '1rem',
        color: '#000000',
        '::placeholder': {
          color: '#e3e3e3',
          fontSize: '1rem',
        },
        // Improved autofill styling
        ':-webkit-autofill': {
          color: '#000000',
          backgroundColor: '#fbfcfe',
        },
        // Add these pseudo-elements for better browser compatibility
        ':-webkit-autofill::first-line': {
          fontSize: '1rem',
        },
        '::selection': {
          backgroundColor: 'rgba(0, 0, 0, 0.1)',
        },
        border: '1px solid ' + '#7963f0', // Add border styling
        borderRadius: '6px', // Optional: Add border-radius for rounded corners
        padding: '24px 32px', // Optional: Add padding for better visual appearance,
        paddingTop: '32px',
        boxShahdow: 'var(--joy-shadowRing, 0 0 #fff),0px 1px 2px 0px rgba(var(--joy-shadowChannel, 255 255 255) / var(--joy-shadowOpacity, 0.08))',
        background: '#fbfcfe',
      },
      invalid: {
        color: '#d3232f',
      },
      theme: 'stripe',
    },
    labels: 'floating',
    hidePostalCode: false,
  };


  return (
    <form onSubmit={handleSubmit} className="space-y-4 text-left">
      {/* email for login */}
      <InputField type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" icon={<Mail />} />
      {/* password for login */}
      <InputField type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder={"Password"} icon={<Key />} />
      {/* password for login */}
      <InputField type="password" value={confirmPass} onChange={e => setConfirmPass(e.target.value)} placeholder={"Confirm Password"} icon={<Key />} />
      <select
        value={plan}
        onChange={e => setPlan(e.target.value)}
        className="w-full border rounded p-2"
      >
        <option value="basic">Basic £1.00/per CV</option>
        <option value="pro">Pro £4.99/month</option>
      </select>

      <div className="border rounded p-2">
        {/* <CardElement /> */}
        <CardElement
          id='card-details'
          options={cardElementOptions}
        />
      </div>

      <button
        type="submit"
        disabled={!stripe || loading}
        className="w-full px-6 py-3 bg-primary text-white rounded-lg"
      >
        {loading ? "Processing..." : "Subscribe"}
      </button>

      {error && <p className="text-red-600">{error}</p>}
    </form>
  );
};

export const UsageLimitModal: React.FC<UsageLimitModalProps> = ({ onClose, isUpgradeFlow }) => {
  // const [loading, setLoading] = useState<'none' | 'onetime' | 'sub'>('none');
  // const [error, setError] = useState<string | null>(null);

  // const handleCheckout = (type: 'onetime' | 'sub') => {
  //   setError(null);
  //   setLoading(type);

  //   const url = type === 'onetime' ? ONETIME_PAYMENT_LINK : SUBSCRIPTION_PAYMENT_LINK;

  //   if (!url) {
  //     setError("The payment link is not configured. Please contact the administrator.");
  //     setLoading('none');
  //     return;
  //   }

  //   // Redirect to the Stripe payment page.
  //   window.location.href = url;
  // };


  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4 max-h-full overflow-auto max-w-full"
      aria-modal="true"
      role="dialog"
    >
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-2xl w-full relative transform transition-all duration-300 ease-out scale-95 animate-fadeInScale max-h-[90vh] overflow-auto">
        {/* close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
          aria-label="Close modal"
        >
          <X className="h-6 w-6" />
        </button>

        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-primary-light mb-4">
            <Crown className="h-10 w-10 text-primary" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">
            {isUpgradeFlow ? 'Upgrade to Pro' : 'Free Quota Reached'}
          </h3>
          <p className="text-gray-600 mb-6 max-w-lg mx-auto">
            {isUpgradeFlow
              ? "Unlock unlimited reviews and refinements by choosing a plan below. Get the professional edge you need!"
              : "You've used your free actions. To continue generating or refining your CV, please choose one of the options below."
            }
          </p>

          <div className="grid grid-cols-1 gap-6 text-left">
            {/* Stripe payment */}
            <Elements stripe={stripePromise}>
              <CheckoutForm closeModal={onClose} />
            </Elements>
          </div>

          {/* {error && (
            <div className="mt-6 bg-red-100 border border-red-200 text-red-800 p-3 rounded-lg flex items-center text-sm">
              <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
              <span><strong>Error:</strong> {error}</span>
            </div>
          )} */}
        </div>
      </div>
    </div>
  );
};
