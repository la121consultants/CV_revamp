
import React, { useState, useEffect, useMemo } from 'react';
import { UserPlus, Trash2, Mail, Key, Star, Clock, CheckCircle, XCircle, AlertCircle, Download } from 'lucide-react';
import { Button } from './Button';
import type { LoggedInUser } from '../types';
import { downloadCvReviewsCSV, getAllNonSuperAdminUsers, signup } from '@/services/firebaseService';
import { Timestamp } from 'firebase/firestore';


interface UserManagerProps {
    loggedInUserEmail: string;
}

// Represents the full user object as stored in localStorage, including password.
interface StoredUser extends LoggedInUser {
    password?: string;
}

const USER_STORAGE_KEY = 'la121Users';

export const UserManager: React.FC<UserManagerProps> = ({ loggedInUserEmail }) => {
    const [users, setUsers] = useState<StoredUser[]>([]);
    const [newUserEmail, setNewUserEmail] = useState('');
    const [newUserPassword, setNewUserPassword] = useState('');
    const [newUserRole, setNewUserRole] = useState<'pro' | 'onetime'>('onetime');
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);

    const getUsers = async () => {
        try {
            // get users data
            const users_list = await getAllNonSuperAdminUsers();
            setUsers(users_list);
            // const usersRaw = localStorage.getItem(USER_STORAGE_KEY);
            // return usersRaw ? JSON.parse(usersRaw) : [];
        } catch {
            console.log("unkonw error !!!");
        }
    };

    const saveUsers = (updatedUsers: StoredUser[]) => {
        // localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updatedUsers));
        // setUsers(updatedUsers);
    };

    useEffect(() => {
        getUsers();
    }, []);

    const handleAddUser = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setSuccess(null);

        if (!newUserEmail || !newUserPassword) {
            setError('Please provide both an email and a password.');
            return;
        }
        if (newUserPassword.length < 8) {
            setError('Password must be at least 8 characters long.');
            return;
        }

        // const currentUsers = getUsers();
        // if (currentUsers.find(user => user.email.toLowerCase() === newUserEmail.toLowerCase())) {
        //     setError('A user with this email already exists.');
        //     return;
        // }

        // const expiryDate = new Date();
        // expiryDate.setDate(expiryDate.getDate() + 30);

        // const newUser: StoredUser = {
        //     email: newUserEmail.toLowerCase(),
        //     password: newUserPassword,
        //     role: newUserRole,
        //     createdAt: new Date().toISOString(),
        //     expiresAt: expiryDate.toISOString(),
        //     usageCount: newUserRole === 'onetime' ? 0 : undefined,
        // };

        // const updatedUsers = [...currentUsers, newUser];
        // saveUsers(updatedUsers);

        // setSuccess(`User ${newUserEmail} created as a ${newUserRole} user.`);
        // setNewUserEmail('');
        // setNewUserPassword('');

        // Create expiry date 30 days from now
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + 30);

        // Convert to Firestore Timestamp
        const expiryTimestamp = Timestamp.fromDate(expiryDate);

        // new user data
        const new_user_data = {
            email: newUserEmail.toLowerCase(),
            password: newUserPassword,
            expire_on: expiryTimestamp,
            is_limited_access: newUserRole === 'onetime',
            usage_limit: (newUserRole === 'onetime' ? 3 : -1),
        };
        // return console.log("new_user_data", new_user_data);
        // save new user data
        await signup(new_user_data);
        // set success
        setTimeout(() => setSuccess(null), 5000);
        // after creating new users fetch users again
        getUsers();
        // reset the form
        e.target.reset();  // resets all input fields
    };

    const handleRemoveUser = (emailToRemove: string) => {
        if (window.confirm(`Are you sure you want to remove the user account for ${emailToRemove}? This action cannot be undone.`)) {
            const currentUsers = getUsers();
            const updatedUsers = currentUsers.filter(user => user.email.toLowerCase() !== emailToRemove.toLowerCase());
            // saveUsers(updatedUsers);
            setSuccess(`User ${emailToRemove} has been removed.`);
            setTimeout(() => setSuccess(null), 3000);
        }
    };

    const getUserStatus = (user): { text: string; color: string; icon: React.ReactNode } => {
        const isExpired = getUserExpiryStatus(user);

        if (user.role === 'superadmin') return { text: 'Active', color: 'text-green-600', icon: <CheckCircle className="h-4 w-4" /> };

        // const isExpired = user.expiresAt && new Date(user.expiresAt) < new Date();
        // if (isExpired) return { text: 'Expired', color: 'text-red-600', icon: <XCircle className="h-4 w-4" /> };

        if (user.is_limited_access) {
            if ((user.tools_usage_count || 0) >= 1) {
                return { text: 'Used', color: 'text-yellow-600', icon: <AlertCircle className="h-4 w-4" /> };
            }
        }

        return { text: 'Active', color: 'text-green-600', icon: <CheckCircle className="h-4 w-4" /> };
    };

    function getUserExpiryStatus(user) {
        // Convert Firestore timestamp to JS Date
        const expireDate = new Date(user.expire_on.seconds * 1000); // multiply by 1000 to get ms

        // Format expiry date for display
        const options = { year: "numeric", month: "short", day: "numeric" };
        const formattedExpiry = expireDate.toLocaleDateString(undefined, options);

        // Check if expired
        const now = new Date();
        const status = now <= expireDate ? "Active" : "Expired";

        return formattedExpiry;
    }

    // const managedUsers = useMemo(() => users, [users]);
    // console.log("managedUsers", managedUsers);

    // const managedUsers = useMemo(() => users.filter(u => u.role !== 'superadmin'), [users]);

    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-3">Create New User</h3>
                <form onSubmit={handleAddUser} className="p-4 bg-gray-50 rounded-lg border space-y-3">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                            <input type="email" value={newUserEmail} onChange={e => setNewUserEmail(e.target.value)} placeholder="New User Email" className="w-full pl-10 p-2 border border-gray-300 rounded-md" />
                        </div>
                        <div className="relative">
                            <Key className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                            <input type="password" value={newUserPassword} onChange={e => setNewUserPassword(e.target.value)} placeholder="Set Password" className="w-full pl-10 p-2 border border-gray-300 rounded-md" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">User Type</label>
                        <select value={newUserRole} onChange={e => setNewUserRole(e.target.value as 'pro' | 'onetime')} className="w-full p-2 border border-gray-300 rounded-md">
                            <option value="onetime">One-Time Use (1 CV, expires in 30 days)</option>
                            <option value="pro">Pro User (Unlimited, expires in 30 days)</option>
                        </select>
                    </div>
                    {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
                    {success && <p className="text-green-600 text-sm mt-2">{success}</p>}
                    <div className="text-right pt-2">
                        <Button type="submit" className="px-4 py-2 text-sm">
                            <UserPlus className="mr-2 h-4 w-4" />
                            Create User
                        </Button>
                    </div>
                </form>
            </div>
            <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">Current Users ({users?.length})</h3>
                <div className="border rounded-lg overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Uage Count</th>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Expires On</th>
                                <th scope="col" className="relative px-4 py-3"><span className="sr-only">Actions</span></th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {users.length === 0 ? (
                                <tr><td colSpan={5} className="p-4 text-center text-gray-500">No users have been created yet.</td></tr>
                            ) : (
                                users.map(user => {
                                    const status = getUserStatus(user);
                                    return (
                                        <tr key={user.email}>
                                            <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-800">{user.email}</td>
                                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 capitalize">
                                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${user.is_limited_access ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                                                    {!user.is_limited_access ? <Star className="h-3 w-3 mr-1" /> : <Clock className="h-3 w-3 mr-1" />}
                                                    {user.is_limited_access ? "one time" : "pro (unlimited access)"}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 text-center">
                                                {user.tools_usage_count}
                                            </td>
                                            <td className={`px-4 py-3 whitespace-nowrap text-sm font-semibold ${status.color}`}>
                                                <div className="flex items-center">{status.icon} <span className="ml-1.5">
                                                    {status.text}
                                                </span></div>
                                            </td>
                                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600">
                                                {/* {user.expiresAt ? new Date(user.expiresAt).toLocaleDateString() : 'N/A'} */}
                                                {
                                                    getUserExpiryStatus(user)
                                                }
                                            </td>
                                            {/* <td className="px-4 py-3 whitespace-nowrap text-right text-sm font-medium">
                                                <button onClick={() => handleRemoveUser(user.email)} className="text-red-500 hover:text-red-700" title={`Delete ${user.email}`}>
                                                    <Trash2 className="h-5 w-5" />
                                                </button>
                                            </td> */}
                                        </tr>
                                    )
                                })
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};
