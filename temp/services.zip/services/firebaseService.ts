// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth, sendPasswordResetEmail, signOut } from "firebase/auth";
import { doc, setDoc, getDoc, collection, query, orderBy, addDoc, serverTimestamp, getDocs, where, Timestamp, updateDoc, increment } from "firebase/firestore";

import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase/auth";
import { FeedbackData } from "./googleSheetService";
import { sendEmail } from "./emailService";


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
      apiKey: "AIzaSyCHPe84j4_OiUhsx8AhzvRkTT0H6BdrwpU",
      authDomain: "la121consultants-aede7.firebaseapp.com",
      projectId: "la121consultants-aede7",
      storageBucket: "la121consultants-aede7.firebasestorage.app",
      messagingSenderId: "296822540339",
      appId: "1:296822540339:web:756673371699a419defb46",
      measurementId: "G-W0WLCSB17D"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const db = getFirestore(app);
export const auth = getAuth(app);

// increment tools usage
export const incrementToolsUsage = async () => {
      // get logged in user from localStorage
      const userData = JSON.parse(localStorage.getItem("user") || "{}");
      if (!userData.uid) throw new Error("User not found");

      const userRef = doc(db, "users", userData.uid);
      await updateDoc(userRef, {
            tools_usage_count: increment(1),
      });
      // get updated user data
      const userSnap = await getDoc(userRef);
      const updatedUser = userSnap.exists() ? { uid: userData.uid, ...userSnap.data() } : null;
      // update user info
      if (updatedUser) {
            // keep localStorage in sync
            localStorage.setItem("user", JSON.stringify(updatedUser));
      }
      console.log("✅ Submission saved & user updated");
}


// save user data into firebase
export const logSubmissionToFirebase = async (userInfo: {
      name: string;
      email: string;
      phone: string;
      location: string;
      targetJobs: string;
      linkedin: string;
      referralSource: string;
      employmentStatus: string;
}) => {
      try {
            // get logged in user from localStorage
            // const userData = JSON.parse(localStorage.getItem("user") || "{}");
            // if (!userData.uid) throw new Error("User not found");
            // update submissions
            await addDoc(collection(db, "cv-reviews"), {
                  ...userInfo,
                  type: "submission",
                  createdAt: serverTimestamp(),
            });
            console.log("✅ User submission saved to Firebase Firestore.");
            // increment usage count
            // const userRef = doc(db, "users", userData.uid);
            // await updateDoc(userRef, {
            //       tools_usage_count: increment(1),
            // });
            // get updated user data
            // const userSnap = await getDoc(userRef);
            // const updatedUser = userSnap.exists() ? { uid: userData.uid, ...userSnap.data() } : null;

            // if (updatedUser) {
            //       // keep localStorage in sync
            //       localStorage.setItem("user", JSON.stringify(updatedUser));
            // }
            // increment tools usage
            // incrementToolsUsage()
      } catch (error) {
            console.error("❌ Failed to save submission:", error);
      }
};

export const downloadCvReviewsCSV = async () => {
  try {
    const querySnapshot = await getDocs(collection(db, "cv-reviews"));

    const data: any[] = [];
    querySnapshot.forEach((doc) => {
      const docData = doc.data();
      // Convert Firestore Timestamp to readable date
      const createdAt = docData.createdAt?.toDate
        ? docData.createdAt.toDate().toLocaleString()
        : "";
      data.push({ id: doc.id, ...docData, createdAt });
    });

    if (data.length === 0) {
      alert("No data found in cv-reviews collection");
      return;
    }

    // Convert JSON to CSV
    const headers = Object.keys(data[0]);
    const csvRows = [];

    // Add headers
    csvRows.push(headers.join(","));

    // Add data rows
    for (const row of data) {
      const values = headers.map((header) => {
        const escaped = ("" + (row[header] ?? "")).replace(/"/g, '""'); // escape quotes
        return `"${escaped}"`;
      });
      csvRows.push(values.join(","));
    }

    // Create Blob and download
    const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cv-reviews-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    console.log("✅ CSV file downloaded successfully!");
  } catch (error) {
    console.error("❌ Failed to export Firestore data:", error);
    alert("Error downloading data: " + error.message);
  }
};

// save feedback data into firebase
export const logFeedbackToFirebase = async (feedbackData: FeedbackData) => {
      try {
            const payload = {
                  ...feedbackData,
                  type: "feedback",
                  timestamp: new Date().toISOString(),
            };

            await addDoc(collection(db, "feedback"), payload);

            console.log("✅ Feedback saved to Firestore:", payload);
      } catch (e) {
            console.error("❌ Failed to save feedback to Firestore:", e);
            throw new Error("Feedback service is not available at the moment.");
      }
};

// get feedbacks
export const getFeedbackFromFirebase = async () => {
      try {
            const q = query(
                  collection(db, "feedback"),
                  orderBy("timestamp", "desc") // newest first
            );

            const querySnapshot = await getDocs(q);

            const feedbackList = querySnapshot.docs.map(doc => ({
                  id: doc.id,
                  ...doc.data(),
            }));

            console.log("✅ Feedback fetched:", feedbackList);
            return feedbackList;
      } catch (e) {
            console.error("❌ Failed to fetch feedback from Firestore:", e);
            throw new Error("Could not load feedback at the moment.");
      }
};


// Signup
export async function signup(data) {
      const { user } = await createUserWithEmailAndPassword(auth, data.email, data.password);
      // Create Firestore document with role field
      await setDoc(doc(db, "users", user.uid), {
            email: user.email,
            role: "user", // default role
            expire_on: data.expire_on,
            is_limited_access: data.is_limited_access,
            tools_usage_count: 0,
            usage_limit: data.usage_limit,
            createdAt: new Date().toISOString(),
      });
      await sendEmail(user.email, "New Subscription", newSignupTemplate)
      console.log("User registered!");
}

// Forgot Password
export async function forgotPassword(email) {
      try {
            // Step 1: Validate email input
            if (!email) {
                  throw new Error("Please enter your email address.");
            }

            // Step 2: Send password reset email via Firebase
            await sendPasswordResetEmail(auth, email);

            console.log("✅ Password reset email sent to:", email);

            // Step 3: Return success response
            return {
                  success: true,
                  message: "Password reset email sent successfully. Please check your inbox.",
            };

      } catch (err) {
            console.error("❌ forgotPassword error:", err);
            // Always throw an Error object
            throw new Error(
                  err?.message || "Failed to send password reset email. Please try again later."
            );
      }
}
// signout
export const logoutUser = async () => {
      const auth = getAuth();
      try {
            await signOut(auth);
            console.log("✅ User signed out successfully.");
      } catch (error) {
            console.error("❌ Error signing out:", error);
      }
};

// Login user and get role
export async function login(email: string, password: string) {
      try {
            // Step 1: Sign in with Firebase Auth
            const { user } = await signInWithEmailAndPassword(auth, email, password);
            console.log("✅ User logged in:", user.email);

            // Step 2: Get user role from Firestore
            const userDocRef = doc(db, "users", user.uid);
            const snap = await getDoc(userDocRef);

            if (snap.exists()) {
                  const data = snap.data();
                  const idToken = await user.getIdToken();

                  return { ...data, uid: user.uid, auth_token: idToken };
            } else {
                  console.warn("⚠️ No user document found for:", user.uid);
                  throw new Error("No user document found in database");
            }

      } catch (err) {
            console.error("❌ login error:", err);
            // Make sure we always throw an Error object
            throw new Error(
                  err?.message || "login failed. Please check credentials."
            );
      }
}

// export async function login(email: string, password: string) {
//       try {
//             // Step 1: Sign in with Firebase Auth
//             const { user } = await signInWithEmailAndPassword(auth, email, password);
//             console.log("✅ User logged in:", user.email);

//             // Step 2: Get user role from Firestore
//             const userDocRef = doc(db, "users", user.uid);
//             const snap = await getDoc(userDocRef);

//             if (snap.exists()) {
//                   const data = snap.data();
//                   const idToken = await user.getIdToken();

//                   // console.log("🔑 Role:", data.role);
//                   return { ...data, uid: user.uid, auth_token: idToken }; // return role + user data
//             } else {
//                   console.log("⚠️ No user document found");
//                   return null;
//             }
//       } catch (error) {
//             console.error("❌ Login failed:", error.message);
//             throw error;
//       }
// }

/**
 * Count total unique submissions that match phone OR email OR linkedin
 */
export const countTotalUniqueSubmissions = async (
      phone: string,
      email: string,
      linkedin?: string // optional
) => {
      try {
            const submissionsRef = collection(db, "cv-reviews");

            const queries = [
                  query(submissionsRef, where("phone", "==", phone)),
                  query(submissionsRef, where("email", "==", email)),
            ];

            // Only add linkedin query if provided and not empty
            if (linkedin && linkedin.trim() !== "") {
                  queries.push(query(submissionsRef, where("linkedin", "==", linkedin)));
            }

            // Run all queries in parallel
            const snapshots = await Promise.all(queries.map((q) => getDocs(q)));

            // Collect unique document IDs
            const uniqueIds = new Set<string>();
            snapshots.forEach((snap) => {
                  snap.forEach((doc) => uniqueIds.add(doc.id));
            });

            const totalCount = uniqueIds.size;
            console.log("📊 Total unique matching submissions:", totalCount);
            return totalCount;
      } catch (error) {
            console.error("❌ Failed to count submissions:", error);
            return 0;
      }
};


// export const countTotalUniqueSubmissions = async (
//       phone: string,
//       email: string,
//       linkedin: string
// ) => {
//       try {
//             const submissionsRef = collection(db, "cv-reviews");

//             // Queries
//             const phoneQuery = query(submissionsRef, where("phone", "==", phone));
//             const emailQuery = query(submissionsRef, where("email", "==", email));
//             const linkedinQuery = query(submissionsRef, where("linkedin", "==", linkedin));

//             // Run queries
//             const [phoneSnap, emailSnap, linkedinSnap] = await Promise.all([
//                   getDocs(phoneQuery),
//                   getDocs(emailQuery),
//                   getDocs(linkedinQuery),
//             ]);

//             // Collect unique document IDs
//             const uniqueIds = new Set<string>();
//             phoneSnap.forEach((doc) => uniqueIds.add(doc.id));
//             emailSnap.forEach((doc) => uniqueIds.add(doc.id));
//             linkedinSnap.forEach((doc) => uniqueIds.add(doc.id));

//             const totalCount = uniqueIds.size;

//             console.log("📊 Total unique matching submissions:", totalCount);
//             return totalCount;
//       } catch (error) {
//             console.error("❌ Failed to count submissions:", error);
//             return 0;
//       }
// };


// ********************************
//          For Dashboard
// ********************************

// Count Submissions Today
export const countSubmissionsToday = async () => {
      const now = new Date();
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);

      const q = query(
            collection(db, "cv-reviews"),
            where("createdAt", ">=", Timestamp.fromDate(startOfDay)),
            where("createdAt", "<", Timestamp.fromDate(endOfDay)),
            where("type", "==", "submission")
      );

      const snapshot = await getDocs(q);
      return snapshot.size;
};

// Count Submissions This Month
export const countSubmissionsThisMonth = async () => {
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const startOfNextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

      const q = query(
            collection(db, "cv-reviews"),
            where("createdAt", ">=", Timestamp.fromDate(startOfMonth)),
            where("createdAt", "<", Timestamp.fromDate(startOfNextMonth)),
            where("type", "==", "submission")
      );

      const snapshot = await getDocs(q);
      return snapshot.size;
};

// Count Total Submissions
export const countTotalSubmissions = async () => {
      const q = query(
            collection(db, "cv-reviews"),
            where("type", "==", "submission")
      );

      const snapshot = await getDocs(q);
      return snapshot.size;
};

// get all users
export async function getAllNonSuperAdminUsers() {
      try {
            const usersRef = collection(db, "users");
            const q = query(usersRef, where("role", "!=", "superadmin")); // exclude superadmin
            // const q = query(usersRef);
            const querySnapshot = await getDocs(q);

            const users = querySnapshot.docs.map(doc => ({
                  uid: doc.id,
                  ...doc.data(),
            }));

            console.log("✅ Non-superadmin users:", users);
            return users;
      } catch (error) {
            console.error("❌ Failed to fetch users:", error);
            throw error;
      }
}

// Fetch all submissions
export const getAllSubmissionsFromFirebase = async () => {
      try {
            const q = query(
                  collection(db, "cv-reviews"),
                  orderBy("createdAt", "desc") // newest first
            );

            const querySnapshot = await getDocs(q);

            const submissions = querySnapshot.docs.map((doc) => ({
                  id: doc.id,
                  ...doc.data(),
            }));

            console.log("📥 All submissions:", submissions);
            return submissions;
      } catch (error) {
            console.error("❌ Failed to fetch submissions:", error);
            return [];
      }
};

const newSignupTemplate = `<main>
    <style type="text/css">
      @media only screen and (min-width: 520px) {
        .u-row {
          width: 500px !important;
        }

        .u-row .u-col {
          vertical-align: top;
        }

        .u-row .u-col-100 {
          width: 500px !important;
        }

      }

      @media (max-width: 520px) {
        .u-row-container {
          max-width: 100% !important;
          padding-left: 0px !important;
          padding-right: 0px !important;
        }

        .u-row .u-col {
          min-width: 320px !important;
          max-width: 100% !important;
          display: block !important;
        }

        .u-row {
          width: 100% !important;
        }

        .u-col {
          width: 100% !important;
        }

        .u-col>div {
          margin: 0 auto;
        }
      }

      body {
        margin: 0;
        padding: 0;
      }

      table,
      tr,
      td {
        vertical-align: top;
        border-collapse: collapse;
      }

      p {
        margin: 0;
      }

      .ie-container table,
      .mso-container table {
        table-layout: fixed;
      }

      * {
        line-height: inherit;
      }

      a[x-apple-data-detectors='true'] {
        color: inherit !important;
        text-decoration: none !important;
      }

      table,
      td {
        color: #000000;
      }

      #u_body a {
        color: rgb(249 115 22 / var(--tw-bg-opacity, 1));
        text-decoration: underline;
      }
    </style>
    <table id="u_body"
      style="border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;min-width: 320px;Margin: 0 auto;background-color: #ffffff;width:100%"
      cellpadding="0" cellspacing="0">
      <tbody>
        <tr style="vertical-align: top">
          <td style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
            <div class="u-row-container" style="padding: 0px;background-color: transparent">
              <div class="u-row"
                style="margin: 0 auto;min-width: 320px;max-width: 500px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: transparent;">
                <div
                  style="border-collapse: collapse;display: table;width: 100%;height: 100%;background-color: transparent;">
                  <div class="u-col u-col-100"
                    style="max-width: 320px;min-width: 500px;display: table-cell;vertical-align: top;">
                    <div
                      style="height: 100%;width: 100% !important;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;">
                      <div
                        style="box-sizing: border-box; height: 100%; padding: 0px;border-top: 0px solid transparent;border-left: 0px solid transparent;border-right: 0px solid transparent;border-bottom: 0px solid transparent;border-radius: 0px;-webkit-border-radius: 0px; -moz-border-radius: 0px;">

                        <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                          cellspacing="0" width="100%" border="0">
                          <tbody>
                            <tr>
                              <td
                                style="overflow-wrap:break-word;word-break:break-word;padding:50px 10px 20px;font-family:arial,helvetica,sans-serif;"
                                align="left">

                                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                  <tr>
                                    <td style="padding-right: 0px;padding-left: 0px;" align="center">
                                      <a href="https://la121consultants.netlify.app/" target="_blank"
                                        style="text-decoration: none;  color: rgb(249, 115, 22);">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                          viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                          stroke-linecap="round" stroke-linejoin="round" style="font-size: x-large;"
                                          aria-hidden="true">
                                          <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path>
                                          <path d="M14 2v4a2 2 0 0 0 2 2h4"></path>
                                          <path d="M10 9H8"></path>
                                          <path d="M16 13H8"></path>
                                          <path d="M16 17H8"></path>
                                        </svg>
                                        <span style="font-size: x-large; font-weight: 700; color: rgb(249, 115, 22);">LA121 AI CV Review</span>
                                      </a>
                                    </td>
                                  </tr>
                                </table>

                              </td>
                            </tr>
                          </tbody>
                        </table>

                        <table style="font-family:arial,helvetica,sans-serif; margin-top: 30px;" role="presentation"
                          cellpadding="0" cellspacing="0" width="100%" border="0">
                          <tbody>
                            <tr>
                              <td
                                style="overflow-wrap:break-word;word-break:break-word;padding:0px 10px;font-family:arial,helvetica,sans-serif;"
                                align="left">
                                <h1
                                  style="margin: 0px; line-height: 140%; text-align: left; word-wrap: break-word; font-size: 22px; font-weight: 700; color: black;">
                                  <span style="color: black;">
                                    Your account has been created successfuly
                                  </span>
                                </h1>
                              </td>
                            </tr>
                          </tbody>
                        </table>

                        <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                          cellspacing="0" width="100%" border="0">
                          <tbody>
                            <tr>
                              <td
                                style="overflow-wrap:break-word;word-break:break-word;padding:0px 10px;font-family:arial,helvetica,sans-serif;"
                                align="left">

                                <div
                                  style="font-size: 16px; line-height: 140%; text-align: left; word-wrap: break-word;">
                                  <p style="line-height: 140%;">
                                    Please visit <strong>LA121 AI CV Review</strong>, sign in to your account, and
                                    explore
                                    our powerful AI-driven resume analysis tool. It provides instant feedback,
                                    personalized suggestions, and detailed insights to help you refine your CV and
                                    improve
                                    your chances of success. Give it a try today and see how your resume can stand out
                                    with AI assistance!

                                  </p>
                                </div>

                              </td>
                            </tr>
                          </tbody>
                        </table>

                        <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                          cellspacing="0" width="100%" border="0">
                          <tbody>
                            <tr>
                              <td
                                style="overflow-wrap:break-word;word-break:break-word;padding:16px 10px;font-family:arial,helvetica,sans-serif;"
                                align="left">

                                <div align="center">
                                  <a href="https://la121consultants.netlify.app/" target="_blank" class="v-button"
                                    style="box-sizing: border-box;display: inline-block;text-decoration: none;-webkit-text-size-adjust: none;text-align: center;color: #FFFFFF; background: rgb(249, 115, 22); border-radius: 4px;-webkit-border-radius: 4px; -moz-border-radius: 4px; width:auto; max-width:100%; overflow-wrap: break-word; word-break: break-word; word-wrap:break-word; mso-border-alt: none;font-size: 18px;">
                                    <span style="display:block;padding:16px 60px;line-height:120%; color: white;"><span
                                        style="line-height: 21.6px; color: white;">Review My Resume</span></span>
                                  </a>
                                </div>

                              </td>
                            </tr>
                          </tbody>
                        </table>

                        <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                          cellspacing="0" width="100%" border="0">
                          <tbody>
                            <tr>
                              <td
                                style="overflow-wrap:break-word;word-break:break-word;padding:30px 10px 0px;font-family:arial,helvetica,sans-serif;"
                                align="left">

                                <h1
                                  style="margin: 0px; line-height: 100%; text-align: left; word-wrap: break-word; font-size: 24px; font-weight: 400; color: black;">
                                  <span><span style="line-height: 24px;"><span style="line-height: 24px; color: black;"><span
                                          style="line-height: 24px; color: black;"><strong>Contact
                                            Us</strong></span></span></span></span>
                                </h1>

                              </td>
                            </tr>
                          </tbody>
                        </table>

                        <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                          cellspacing="0" width="100%" border="0">
                          <tbody>
                            <tr>
                              <td
                                style="overflow-wrap:break-word;word-break:break-word;padding:10px 10px 30px;font-family:arial,helvetica,sans-serif;"
                                align="left">

                                <div
                                  style="font-size: 14px; color: #000000; line-height: 140%; text-align: left; word-wrap: break-word;">

                                  <p style="line-height: 140%;"><strong>Phone number:</strong> <span
                                      style="color: #000000; line-height: 19.6px;"><a rel="noopener"
                                        href="tel:+447716390812" target="_blank" style="color: #000000;">+44 7716
                                        390812</a></span></p>
                                  <p style="line-height: 140%;"><strong>email:</strong> <span
                                      style="color: #000000; line-height: 19.6px;"><a rel="noopener"
                                        href="mailto:admin@la121consultants.co.uk?subject=la121consultants"
                                        target="_blank"
                                        style="color: #000000;">admin@la121consultants.co.uk</a></span><br />
                                    <span style="color: #000000; line-height: 19.6px;"></span>
                                  </p>

                                </div>

                              </td>
                            </tr>
                          </tbody>
                        </table>



                        <table style="font-family:arial,helvetica,sans-serif;" role="presentation" cellpadding="0"
                          cellspacing="0" width="100%" border="0">
                          <tbody>
                            <tr>
                              <td
                                style="overflow-wrap:break-word;word-break:break-word;padding:0px 10px 50px;font-family:arial,helvetica,sans-serif;"
                                align="left">

                                <div align="center">
                                  <p style="line-height: 140%; text-align: center;">© 2025 LA121 AI CV Review. All
                                    Rights
                                    Reserved.

                                  </p>
                                  <div style="display: table; max-width:184px;">


                                    <table align="left" border="0" cellspacing="0" cellpadding="0" width="32"
                                      height="32"
                                      style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 5px">
                                      <tbody>
                                        <tr style="vertical-align: top">
                                          <td align="left" valign="middle"
                                            style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                            <a href="https://www.linkedin.com/in/la121/" target="_blank"
                                              class="wp-block-social-link-anchor"><svg width="24" height="24"
                                                viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                                                aria-hidden="true" focusable="false">
                                                <path
                                                  d="M19.7,3H4.3C3.582,3,3,3.582,3,4.3v15.4C3,20.418,3.582,21,4.3,21h15.4c0.718,0,1.3-0.582,1.3-1.3V4.3 C21,3.582,20.418,3,19.7,3z M8.339,18.338H5.667v-8.59h2.672V18.338z M7.004,8.574c-0.857,0-1.549-0.694-1.549-1.548 c0-0.855,0.691-1.548,1.549-1.548c0.854,0,1.547,0.694,1.547,1.548C8.551,7.881,7.858,8.574,7.004,8.574z M18.339,18.338h-2.669 v-4.177c0-0.996-0.017-2.278-1.387-2.278c-1.389,0-1.601,1.086-1.601,2.206v4.249h-2.667v-8.59h2.559v1.174h0.037 c0.356-0.675,1.227-1.387,2.526-1.387c2.703,0,3.203,1.779,3.203,4.092V18.338z">
                                                </path>
                                              </svg></a>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <table align="left" border="0" cellspacing="0" cellpadding="0" width="32"
                                      height="32"
                                      style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 5px">
                                      <tbody>
                                        <tr style="vertical-align: top">
                                          <td align="left" valign="middle"
                                            style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                            <a href="https://www.instagram.com/la121consultants/"
                                              class="wp-block-social-link-anchor" target="_blank"><svg width="24"
                                                height="24" viewBox="0 0 24 24" version="1.1"
                                                xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                                                <path
                                                  d="M12,4.622c2.403,0,2.688,0.009,3.637,0.052c0.877,0.04,1.354,0.187,1.671,0.31c0.42,0.163,0.72,0.358,1.035,0.673 c0.315,0.315,0.51,0.615,0.673,1.035c0.123,0.317,0.27,0.794,0.31,1.671c0.043,0.949,0.052,1.234,0.052,3.637 s-0.009,2.688-0.052,3.637c-0.04,0.877-0.187,1.354-0.31,1.671c-0.163,0.42-0.358,0.72-0.673,1.035 c-0.315,0.315-0.615,0.51-1.035,0.673c-0.317,0.123-0.794,0.27-1.671,0.31c-0.949,0.043-1.233,0.052-3.637,0.052 s-2.688-0.009-3.637-0.052c-0.877-0.04-1.354-0.187-1.671-0.31c-0.42-0.163-0.72-0.358-1.035-0.673 c-0.315-0.315-0.51-0.615-0.673-1.035c-0.123-0.317-0.27-0.794-0.31-1.671C4.631,14.688,4.622,14.403,4.622,12 s0.009-2.688,0.052-3.637c0.04-0.877,0.187-1.354,0.31-1.671c0.163-0.42,0.358-0.72,0.673-1.035 c0.315-0.315,0.615-0.51,1.035-0.673c0.317-0.123,0.794-0.27,1.671-0.31C9.312,4.631,9.597,4.622,12,4.622 M12,3 C9.556,3,9.249,3.01,8.289,3.054C7.331,3.098,6.677,3.25,6.105,3.472C5.513,3.702,5.011,4.01,4.511,4.511 c-0.5,0.5-0.808,1.002-1.038,1.594C3.25,6.677,3.098,7.331,3.054,8.289C3.01,9.249,3,9.556,3,12c0,2.444,0.01,2.751,0.054,3.711 c0.044,0.958,0.196,1.612,0.418,2.185c0.23,0.592,0.538,1.094,1.038,1.594c0.5,0.5,1.002,0.808,1.594,1.038 c0.572,0.222,1.227,0.375,2.185,0.418C9.249,20.99,9.556,21,12,21s2.751-0.01,3.711-0.054c0.958-0.044,1.612-0.196,2.185-0.418 c0.592-0.23,1.094-0.538,1.594-1.038c0.5-0.5,0.808-1.002,1.038-1.594c0.222-0.572,0.375-1.227,0.418-2.185 C20.99,14.751,21,14.444,21,12s-0.01-2.751-0.054-3.711c-0.044-0.958-0.196-1.612-0.418-2.185c-0.23-0.592-0.538-1.094-1.038-1.594 c-0.5-0.5-1.002-0.808-1.594-1.038c-0.572-0.222-1.227-0.375-2.185-0.418C14.751,3.01,14.444,3,12,3L12,3z M12,7.378 c-2.552,0-4.622,2.069-4.622,4.622S9.448,16.622,12,16.622s4.622-2.069,4.622-4.622S14.552,7.378,12,7.378z M12,15 c-1.657,0-3-1.343-3-3s1.343-3,3-3s3,1.343,3,3S13.657,15,12,15z M16.804,6.116c-0.596,0-1.08,0.484-1.08,1.08 s0.484,1.08,1.08,1.08c0.596,0,1.08-0.484,1.08-1.08S17.401,6.116,16.804,6.116z">
                                                </path>
                                              </svg></a>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <table align="left" border="0" cellspacing="0" cellpadding="0" width="32"
                                      height="32"
                                      style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 0px">
                                      <tbody>
                                        <tr style="vertical-align: top">
                                          <td align="left" valign="middle"
                                            style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                            <a href="https://www.youtube.com/@la121consultants"
                                              class="wp-block-social-link-anchor" target="_blank"><svg width="24"
                                                height="24" viewBox="0 0 24 24" version="1.1"
                                                xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                                                <path
                                                  d="M21.8,8.001c0,0-0.195-1.378-0.795-1.985c-0.76-0.797-1.613-0.801-2.004-0.847c-2.799-0.202-6.997-0.202-6.997-0.202 h-0.009c0,0-4.198,0-6.997,0.202C4.608,5.216,3.756,5.22,2.995,6.016C2.395,6.623,2.2,8.001,2.2,8.001S2,9.62,2,11.238v1.517 c0,1.618,0.2,3.237,0.2,3.237s0.195,1.378,0.795,1.985c0.761,0.797,1.76,0.771,2.205,0.855c1.6,0.153,6.8,0.201,6.8,0.201 s4.203-0.006,7.001-0.209c0.391-0.047,1.243-0.051,2.004-0.847c0.6-0.607,0.795-1.985,0.795-1.985s0.2-1.618,0.2-3.237v-1.517 C22,9.62,21.8,8.001,21.8,8.001z M9.935,14.594l-0.001-5.62l5.404,2.82L9.935,14.594z">
                                                </path>
                                              </svg></a>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                                </div>

                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </main>`;